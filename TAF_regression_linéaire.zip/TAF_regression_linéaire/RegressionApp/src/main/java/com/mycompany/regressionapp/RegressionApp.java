/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.regressionapp;

/**
 *
 * @author STI
 */
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Arrays;

public class RegressionApp extends JFrame {

    private final JTable dataTable;
    private final JLabel equationLabel = new JLabel("Équation : y = ax + b");
    private final JTextField predictField = new JTextField(10);
    private final JLabel predictResult = new JLabel("Résultat : ");
    private final JPanel graphPanel = new JPanel();
    private double a = 0, b = 0;

    public RegressionApp() {
        setTitle("Régression Linéaire - Budget vs Ventes");
        setSize(800, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Table de données (2 colonnes, 7 lignes)
        String[] columns = {"Budget", "Ventes"};
        Object[][] emptyData = new Object[7][2];
        dataTable = new JTable(new DefaultTableModel(emptyData, columns));
        JScrollPane scrollPane = new JScrollPane(dataTable);
        scrollPane.setPreferredSize(new Dimension(400, 130));

        // Haut de la fenêtre
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        topPanel.add(new JLabel("Entrez les données de Budget et Ventes :"));
        topPanel.add(scrollPane);

        JButton computeButton = new JButton("Calculer la régression");
        computeButton.addActionListener(this::onCompute);
        topPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        topPanel.add(computeButton);
        topPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        topPanel.add(equationLabel);

        JPanel predictPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        predictPanel.add(new JLabel("Budget à prédire :"));
        predictPanel.add(predictField);
        JButton predictButton = new JButton("Prédire");
        predictButton.addActionListener(this::onPredict);
        predictPanel.add(predictButton);
        predictPanel.add(predictResult);

        topPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        topPanel.add(predictPanel);

        add(topPanel, BorderLayout.NORTH);

        // Graphique au centre
        graphPanel.setLayout(new BorderLayout());
        graphPanel.setPreferredSize(new Dimension(800, 400));
        add(graphPanel, BorderLayout.CENTER);
    }

    private void onCompute(ActionEvent e) {
        try {
            int rowCount = dataTable.getRowCount();
            double[] x = new double[rowCount];
            double[] y = new double[rowCount];

            for (int i = 0; i < rowCount; i++) {
                String valX = String.valueOf(dataTable.getValueAt(i, 0));
                String valY = String.valueOf(dataTable.getValueAt(i, 1));
                x[i] = Double.parseDouble(valX);
                y[i] = Double.parseDouble(valY);
            }

            // Calcul régression
            int n = x.length;
            double sumX = Arrays.stream(x).sum();
            double sumY = Arrays.stream(y).sum();
            double sumXY = 0, sumX2 = 0;

            for (int i = 0; i < n; i++) {
                sumXY += x[i] * y[i];
                sumX2 += x[i] * x[i];
            }

            a = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
            b = (sumY - a * sumX) / n;

            equationLabel.setText(String.format("Équation : y = %.4fx + %.4f", a, b));

            drawChart(x, y);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur dans la saisie des données.");
        }
    }

    private void drawChart(double[] x, double[] y) {
        XYSeries series = new XYSeries("Données");
        for (int i = 0; i < x.length; i++) {
            series.add(x[i], y[i]);
        }

        XYSeries line = new XYSeries("Régression");
        double minX = Arrays.stream(x).min().orElse(0);
        double maxX = Arrays.stream(x).max().orElse(1);
        line.add(minX, a * minX + b);
        line.add(maxX, a * maxX + b);

        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);
        dataset.addSeries(line);

        JFreeChart chart = ChartFactory.createXYLineChart(
                "Régression Linéaire",
                "Budget",
                "Ventes",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false
        );

        XYPlot plot = chart.getXYPlot();
        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinePaint(Color.LIGHT_GRAY);
        plot.setRangeGridlinePaint(Color.LIGHT_GRAY);
        plot.setDomainGridlinesVisible(true);
        plot.setRangeGridlinesVisible(true);

        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setSeriesLinesVisible(0, false); // points
        renderer.setSeriesShapesVisible(0, true);
        renderer.setSeriesPaint(0, Color.BLUE);

        renderer.setSeriesLinesVisible(1, true); // droite
        renderer.setSeriesShapesVisible(1, false);
        renderer.setSeriesPaint(1, Color.RED);

        plot.setRenderer(renderer);

        graphPanel.removeAll();
        graphPanel.add(new ChartPanel(chart), BorderLayout.CENTER);
        graphPanel.revalidate();
        graphPanel.repaint();
    }

    private void onPredict(ActionEvent e) {
        try {
            double xVal = Double.parseDouble(predictField.getText());
            double yVal = a * xVal + b;
            predictResult.setText(String.format("Résultat : %.2f ventes", yVal));
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Veuillez entrer un budget valide.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RegressionApp app = new RegressionApp();
            app.setVisible(true);
        });
    }
}
